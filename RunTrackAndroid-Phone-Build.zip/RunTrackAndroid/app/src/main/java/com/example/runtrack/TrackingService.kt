package com.example.runtrack

import android.app.*
import android.content.Intent
import android.location.Location
import android.os.IBinder
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

class TrackingService : Service(), TextToSpeech.OnInitListener {
    private lateinit var fused: FusedLocationProviderClient
    private var callback: LocationCallback? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var startedAt = 0L
    private var pausedAt = 0L
    private var pausedTotal = 0L
    private var paused = false
    private var distanceMeters = 0.0
    private var lastLocation: Location? = null
    private var lastSplitMeters = 0.0
    private var lastSplitSeconds = 0L
    private var splitIndex = 1
    private val splitTimes = mutableListOf<String>()
    private val route = JSONArray()

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        tts = TextToSpeech(this, this)
        createChannel()
    }

    override fun onInit(status: Int) { ttsReady = status == TextToSpeech.SUCCESS }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> begin()
            ACTION_PAUSE -> togglePause()
            ACTION_STOP -> finishWorkout()
        }
        return START_NOT_STICKY
    }

    private fun begin() {
        if (startedAt != 0L) return
        startedAt = System.currentTimeMillis()
        startForeground(NOTIFICATION_ID, notification("GPS tracking is active"))
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(700L)
            .setMinUpdateDistanceMeters(2f)
            .build()
        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                if (paused) return
                for (loc in result.locations) processLocation(loc)
                broadcastUpdate()
            }
        }
        try {
            fused.requestLocationUpdates(request, callback!!, mainLooper)
        } catch (_: SecurityException) {
            stopSelf()
        }
    }

    private fun processLocation(loc: Location) {
        if (!loc.hasAccuracy() || loc.accuracy > 25f) return
        val previous = lastLocation
        if (previous != null) {
            val dt = (loc.time - previous.time).coerceAtLeast(1L) / 1000.0
            val segment = previous.distanceTo(loc).toDouble()
            // Filter stationary GPS drift and implausible jumps. These thresholds are conservative defaults.
            if (segment < 2.0) return
            if (dt <= 0 || segment / dt > 7.0) return
            distanceMeters += segment
        }
        lastLocation = loc
        route.put(JSONObject().put("lat", loc.latitude).put("lon", loc.longitude).put("accuracy", loc.accuracy))
        if (distanceMeters >= splitIndex * 1000.0) {
            val elapsed = elapsedSeconds()
            val splitDuration = elapsed - lastSplitSeconds
            val splitText = formatClock(splitDuration)
            splitTimes.add("$splitIndex km: $splitText")
            if (ttsReady) tts?.speak("Kilometer $splitIndex completed. Split time $splitDuration seconds.", TextToSpeech.QUEUE_ADD, null, "split$splitIndex")
            lastSplitSeconds = elapsed
            lastSplitMeters = distanceMeters
            splitIndex++
        }
    }

    private fun elapsedSeconds(): Long {
        val end = if (paused) pausedAt else System.currentTimeMillis()
        return ((end - startedAt - pausedTotal).coerceAtLeast(0L)) / 1000L
    }

    private fun togglePause() {
        if (startedAt == 0L) return
        if (!paused) {
            paused = true
            pausedAt = System.currentTimeMillis()
            callback?.let { fused.removeLocationUpdates(it) }
            lastLocation = null
            if (ttsReady) tts?.speak("Workout paused", TextToSpeech.QUEUE_ADD, null, "pause")
        } else {
            pausedTotal += System.currentTimeMillis() - pausedAt
            paused = false
            lastLocation = null
            val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
                .setMinUpdateIntervalMillis(700L).setMinUpdateDistanceMeters(2f).build()
            callback = object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    if (!paused) { result.locations.forEach { processLocation(it) }; broadcastUpdate() }
                }
            }
            try { fused.requestLocationUpdates(request, callback!!, mainLooper) } catch (_: SecurityException) {}
            if (ttsReady) tts?.speak("Workout resumed", TextToSpeech.QUEUE_ADD, null, "resume")
        }
        broadcastUpdate()
        updateNotification(if (paused) "Workout paused" else "GPS tracking is active")
    }

    private fun broadcastUpdate() {
        sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName)
            .putExtra("distance", distanceMeters / 1000.0)
            .putExtra("elapsed", elapsedSeconds())
            .putExtra("paused", paused))
        updateNotification("${"%.2f".format(distanceMeters / 1000.0)} km • ${formatClock(elapsedSeconds())}")
    }

    private fun finishWorkout() {
        if (startedAt == 0L) { stopSelf(); return }
        if (paused) pausedTotal += System.currentTimeMillis() - pausedAt
        callback?.let { fused.removeLocationUpdates(it) }
        val elapsed = elapsedSeconds()
        val km = distanceMeters / 1000.0
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        val splitString = if (splitTimes.isEmpty()) "No full km splits" else splitTimes.joinToString("; ")
        val prefs = getSharedPreferences("runtrack", MODE_PRIVATE)
        val arr = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        arr.put(JSONObject().put("date", date).put("km", "%.2f".format(Locale.US, km))
            .put("time", formatClock(elapsed)).put("splits", splitString)
            .put("routePoints", route.length()))
        prefs.edit().putString("history", arr.toString()).apply()
        if (ttsReady) tts?.speak("Workout complete. Distance ${"%.2f".format(Locale.US, km)} kilometers. Total time ${formatClock(elapsed)}.", TextToSpeech.QUEUE_FLUSH, null, "finish")
        sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName).putExtra("distance", km).putExtra("elapsed", elapsed).putExtra("paused", false))
        startedAt = 0L
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun formatClock(sec: Long): String = "%02d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
    private fun createChannel() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Workout tracking", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun notification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("RunTrack").setContentText(text)
        .setOngoing(true).setPriority(NotificationCompat.PRIORITY_LOW).build()
    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        callback?.let { fused.removeLocationUpdates(it) }
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
    companion object {
        const val ACTION_START = "com.example.runtrack.START"
        const val ACTION_PAUSE = "com.example.runtrack.PAUSE"
        const val ACTION_STOP = "com.example.runtrack.STOP"
        const val ACTION_UPDATE = "com.example.runtrack.UPDATE"
        const val CHANNEL_ID = "runtrack_tracking"
        const val NOTIFICATION_ID = 901
    }
}
