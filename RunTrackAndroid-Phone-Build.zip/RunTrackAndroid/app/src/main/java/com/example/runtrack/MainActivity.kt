package com.example.runtrack

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var stats: TextView
    private lateinit var status: TextView
    private lateinit var history: TextView
    private lateinit var startBtn: Button
    private lateinit var pauseBtn: Button
    private lateinit var stopBtn: Button
    private var tracking = false
    private var paused = false
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != TrackingService.ACTION_UPDATE) return
            val distance = intent.getDoubleExtra("distance", 0.0)
            val elapsed = intent.getLongExtra("elapsed", 0L)
            val pace = if (distance > 0.02) elapsed / 60.0 / distance else 0.0
            stats.text = "Distance  ${"%.2f".format(distance)} km\nTime  ${formatTime(elapsed)}\nAverage pace  ${if (pace > 0) "%.2f".format(pace) + " min/km" else "--"}"
            status.text = if (intent.getBooleanExtra("paused", false)) "Paused" else "GPS tracking active"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 20)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply { text = "RUNTRACK"; textSize = 28f; gravity = Gravity.CENTER; setPadding(0, 4, 0, 14) })
        status = TextView(this).apply { text = "Ready to move"; textSize = 16f; gravity = Gravity.CENTER }
        root.addView(status)
        stats = TextView(this).apply { text = "Distance  0.00 km\nTime  00:00:00\nAverage pace  --"; textSize = 23f; gravity = Gravity.CENTER; setPadding(0, 24, 0, 24) }
        root.addView(stats)
        startBtn = Button(this).apply { text = "Start workout"; setOnClickListener { if (hasLocationPermission()) startWorkout() else requestPermissionsNow() } }
        root.addView(startBtn, matchWidth())
        pauseBtn = Button(this).apply { text = "Pause / Resume"; isEnabled = false; setOnClickListener { sendAction(TrackingService.ACTION_PAUSE) } }
        root.addView(pauseBtn, matchWidth())
        stopBtn = Button(this).apply { text = "Finish & save"; isEnabled = false; setOnClickListener { sendAction(TrackingService.ACTION_STOP) } }
        root.addView(stopBtn, matchWidth())
        root.addView(TextView(this).apply { text = "Recent workouts"; textSize = 20f; setPadding(0, 20, 0, 8) })
        history = TextView(this).apply { textSize = 14f }
        root.addView(history)
        root.addView(TextView(this).apply {
            text = "For best results, go outdoors with Location enabled. Keep RunTrack's location permission set to Allow while using the app. GPS accuracy varies by phone and surroundings."
            textSize = 12f; setPadding(0, 18, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
        loadHistory()
    }

    private fun matchWidth() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun hasLocationPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestPermissionsNow() {
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, perms.toTypedArray(), 20)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 20 && hasLocationPermission()) startWorkout()
        else status.text = "Location permission is required to track a workout."
    }

    private fun startWorkout() {
        val i = Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_START)
        ContextCompat.startForegroundService(this, i)
        tracking = true; paused = false
        startBtn.isEnabled = false; pauseBtn.isEnabled = true; stopBtn.isEnabled = true
        status.text = "Getting GPS fix…"
    }

    private fun sendAction(action: String) {
        val i = Intent(this, TrackingService::class.java).setAction(action)
        startService(i)
        if (action == TrackingService.ACTION_STOP) {
            tracking = false; paused = false
            startBtn.isEnabled = true; pauseBtn.isEnabled = false; stopBtn.isEnabled = false
            status.text = "Workout saved"
            loadHistory()
        }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(this, receiver, IntentFilter(TrackingService.ACTION_UPDATE), ContextCompat.RECEIVER_NOT_EXPORTED)
    }
    override fun onStop() { unregisterReceiver(receiver); super.onStop() }

    private fun loadHistory() {
        val arr = getSharedPreferences("runtrack", MODE_PRIVATE).getString("history", "[]") ?: "[]"
        val json = JSONArray(arr)
        if (json.length() == 0) { history.text = "No workouts saved yet."; return }
        val lines = mutableListOf<String>()
        for (i in json.length() - 1 downTo maxOf(0, json.length() - 10)) {
            val o = json.getJSONObject(i)
            lines.add("${o.optString("date")}  •  ${o.optString("km")} km  •  ${o.optString("time")}  •  ${o.optString("splits")}")
        }
        history.text = lines.joinToString("\n\n")
    }

    private fun formatTime(seconds: Long): String {
        val s = seconds.coerceAtLeast(0)
        return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    }
}
